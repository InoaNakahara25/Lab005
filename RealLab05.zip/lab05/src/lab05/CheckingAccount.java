package lab05;

class CheckingAccount extends BankAccount {
    private TransactionLogger transactionLogger;
    private double overdraftFee = 35;

    public CheckingAccount(int accountNumber, String holderName, double balance) {
        super(accountNumber, holderName, balance, "Checking");
        this.transactionLogger = new TransactionLogger();
        
    }

    @Override
    public double getBalance() {
        return balance;
    }

    @Override
    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber + " | Holder: " + holderName + " | Balance: $" + balance);
    }


    @Override
    public double withdraw(double amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawal successful. New balance: $" + balance);
            transactionLogger.logTransaction("Withdrew " + amount);
            if(amount == 500) {
            	System.out.println("Overdraft, but no fee");
            	transactionLogger.logTransaction("Overdraft, but no fee");
            	
            }
        if (amount<500) {
        	return 0;
        }else if (amount > 500) {
                balance -= overdraftFee;
                System.out.println("Overdraft used.");
                System.out.println("Overdraft fee of $" + overdraftFee + " applied.");
                transactionLogger.logTransaction("Overdraft fee of $" + overdraftFee + " applied.");
                System.out.println("New balance after overdraft: $" + balance);
         }
        }else {
            System.out.println("Insufficient funds! Withdrawal denied.");
        }
        return balance;
    }
    
    public boolean Transfer(CheckingAccount recipient, double amount) {
        if (balance - amount < -500) { 
            System.out.println("Transfer failed! Insufficient funds (overdraft limit exceeded).");
            return false;
        }

        if (amount > 500) {
            System.out.println("Transfer exceeds $500! Overdraft fee applied.");
        }

        this.withdraw(amount);
        recipient.deposit(amount);
        logTransaction("Transferred $" + amount + " to " + recipient.holderName);
        recipient.logTransaction("Received $" + amount + " from " + this.holderName);
        System.out.println("Transfer successful! $" + amount + " sent to " + recipient.holderName);
        return true;
    }





    public void logTransaction(String message) {
        transactionLogger.logTransaction(message);
    }

    public void displayTransactionHistory() {
        transactionLogger.displayLogs();
    }
    
}