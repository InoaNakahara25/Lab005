package lab05;

class SavingsAccount extends BankAccount {
	private TransactionLogger transactionLogger;
    public SavingsAccount(int accountNumber, String holderName, double balance) {
        super(accountNumber, holderName, balance, "Savings");
        this.transactionLogger = new TransactionLogger();
        balance+= balance * 0.04;
    }

    @Override
    public double getBalance() {
    	if(balance < 100) {
    		System.out.println("Insufficient funds! Minimum balance must be $100");
    		}
    	return balance;
    }
    @Override
    public double withdraw(double amount) {
        if (balance - amount < 100) {
            System.out.println("Insufficient funds! Minimum balance must be $100");
        } else {
            balance -= amount;
            System.out.println("Withdrawal successful. New balance: $" + balance);
            transactionLogger.logTransaction("Withdrew $" + amount);
        }
        return balance;
    }
    
    public void applyInterest() {
        balance += balance * 0.04;
        transactionLogger.logTransaction("Intrest Applied, new balance: " + balance);
    }

    @Override
    public void displayAccountInfo() {
        System.out.println("Account Number: " + accountNumber + " | Holder: " + holderName + " | Balance: $" + balance);
    
    if(balance < 100) {
    	System.out.println("Insufficient funds! Minimum balance must be $100");
    	}
}
}