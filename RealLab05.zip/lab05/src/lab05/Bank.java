package lab05;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Bank {
    private ArrayList<BankAccount> accounts = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private TransactionLogger transactionLogger = new TransactionLogger(); 

    public void createAccount() {
        Random rand = new Random();
        int accNumber = rand.nextInt(9000) + 1000; 

        System.out.println("Enter Account Type (Savings/Checking):");
        String type = scanner.next();
        System.out.println("Enter Holder Name:");
        String holderName = scanner.next();
        System.out.println("Enter Initial Balance:");
        double balance = scanner.nextDouble();

        if (type.equalsIgnoreCase("Savings") && balance >= 100) {
            accounts.add(new SavingsAccount(accNumber, holderName, balance+=balance*0.04));
            System.out.println("Savings Account created successfully. Account Number: " + accNumber);
            transactionLogger.logTransaction("Intrest Applied, new balance: " + balance);
        } else if (balance < 100) {
            System.out.println("Must have a minimum of $100 in Savings!");
            return;
        } else if (type.equalsIgnoreCase("Checking")) {
            accounts.add(new CheckingAccount(accNumber, holderName, balance));
            System.out.println("Checking Account created successfully. Account Number: " + accNumber);
        } else {
            System.out.println("Invalid account type.");
        }

        transactionLogger.logTransaction("Account Created: #" + accNumber + " | Holder: " + holderName + " | Balance: $" + balance);
    }

    public BankAccount findAccount(int accountNumber) {
        for (BankAccount account : accounts) {
            if (account.accountNumber == accountNumber) {
                return account;
            }
        }
        return null; // Return null if no account is found
    }

    public void depositToAccount() {
        System.out.println("Enter Account Number:");
        int accNumber = scanner.nextInt();

        BankAccount account = findAccount(accNumber);
        if (account == null) {
            System.out.println("Account not found!");
            return;
        }

        System.out.println("Enter Amount to Deposit:");
        double amount = scanner.nextDouble();

        account.deposit(amount);
        transactionLogger.logTransaction("Acc #" + accNumber + ": Deposited $" + amount);
        System.out.println("Deposit successful. New balance: $" + account.getBalance());
    }

    public void withdrawFromAccount() {
        System.out.println("Enter Account Number:");
        int accNumber = scanner.nextInt();

        BankAccount account = findAccount(accNumber);
        if (account == null) {
            System.out.println("Account not found!");
            return;
        }

        System.out.println("Enter Amount to Withdraw:");
        double amount = scanner.nextDouble();

        if (account.getBalance() >= amount) {
            account.withdraw(amount);
            transactionLogger.logTransaction("Acc #" + accNumber + ": Withdrew $" + amount);
            System.out.println("Withdrawal complete. New balance: $" + account.getBalance());
        } else {
            System.out.println("Insufficient funds! Transaction canceled.");
        }
    }

    public void transferBetweenAccounts() {
        System.out.println("Enter Your Account Number:");
        int senderAcc = scanner.nextInt();
        BankAccount sender = findAccount(senderAcc);

        if (sender == null || !(sender instanceof CheckingAccount)) {
            System.out.println("Invalid sender account or transfers allowed only for Checking accounts.");
            return;
        }

        System.out.println("Enter Recipient Account Number:");
        int recipientAcc = scanner.nextInt();
        BankAccount recipient = findAccount(recipientAcc);

        if (recipient == null) {
            System.out.println("Recipient account not found!");
            return;
        }

        System.out.println("Enter Amount to Transfer:");
        double amount = scanner.nextDouble();

        if (sender.getBalance() >= amount) {
            CheckingAccount senderAccount = (CheckingAccount) sender;
            senderAccount.Transfer((CheckingAccount) recipient, amount);
            transactionLogger.logTransaction("Acc #" + senderAcc + " transferred $" + amount + " to Acc #" + recipientAcc);
        } else {
            System.out.println("Insufficient funds! Transfer canceled.");
        }
    }

    public void displayAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts found.");
            return;
        }
        for (BankAccount account : accounts) {
            account.displayAccountInfo();
        }
    }

    public void showTransactionHistory() {
        System.out.println("Enter Account Number:");
        int accNumber = scanner.nextInt();

        System.out.println("\nTransaction history for Account #" + accNumber);

        switch (accounts.isEmpty() ? "empty" : "show") {
            case "empty":
                System.out.println("No transactions found.");
                break;
            case "show":
                transactionLogger.displayLogs();
                break;
            default:
                System.out.println("Unexpected error.");
        }
    }

    public static void main(String[] args) {
        Bank bank = new Bank();

        while (true) {
            System.out.println("\n1. Create Account\n2. Deposit\n3. Withdraw\n4. Transfer\n5. View Accounts\n6. View Transactions\n7. Exit");
            int choice = bank.scanner.nextInt();

            switch (choice) {
                case 1:
                    bank.createAccount();
                    break;
                case 2:
                    bank.depositToAccount();
                    break;
                case 3:
                    bank.withdrawFromAccount();
                    break;
                case 4:
                    bank.transferBetweenAccounts();
                    break;
                case 5:
                    bank.displayAccounts();
                    break;
                case 6:
                    bank.showTransactionHistory();
                    break;
                case 7:
                    System.out.println("Exiting system.");
                    return;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }
}
