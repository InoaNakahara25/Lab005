package lab05;
import java.util.ArrayList;
class TransactionLogger {
    private ArrayList<String> logHistory;

    public TransactionLogger() {
        logHistory = new ArrayList<>();
    }

    public void logTransaction(String message) {
        logHistory.add(message);
    }

    public void displayLogs() {
        if (logHistory.isEmpty()) {
            System.out.println("No transactions to display.");
        } else {
            for (String log : logHistory) {
                System.out.println(log);
            }
        }
    }
}
