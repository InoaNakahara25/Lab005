package lab05;

abstract class BankAccount {
    public int accountNumber;
    public String holderName;
    public double balance;
    public String accountType;

    public BankAccount(int accountNumber, String holderName, double balance, String accountType) {
        this.accountNumber = accountNumber;
        this.holderName = holderName;
        this.balance = balance;
        this.accountType = accountType;
    }

    public double deposit(double amount) {
        balance += amount;
        System.out.println("Deposit successful. New balance: $" + balance);
        return balance;
    }

    public double withdraw(double amount) {
        if (balance < amount) {
            System.out.println("Insufficient funds!");
        } else {
            balance -= amount;
            System.out.println("Withdrawal successful. New balance: $" + balance);
        }
        return balance;
    }

    public abstract double getBalance();
    public abstract void displayAccountInfo();
}
